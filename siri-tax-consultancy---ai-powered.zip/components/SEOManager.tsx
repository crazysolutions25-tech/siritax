
import React, { useEffect } from 'react';
import { DetailedService } from '../constants';

interface SEOManagerProps {
  currentPage: string;
  selectedService: DetailedService | null;
}

const SEOManager: React.FC<SEOManagerProps> = ({ currentPage, selectedService }) => {
  useEffect(() => {
    let title = "Siri Tax Consultancy | GST & ITR Experts Vizag, Srikakulam";
    let description = "Expert tax filing and financial consultancy in Visakhapatnam and Srikakulam. GST, ITR, Tally, and more.";
    
    // Dynamic Page Titles & Descriptions
    if (currentPage === 'home') {
      title = "Siri Tax Consultancy | Professional Tax Experts in Andhra Pradesh";
    } else if (currentPage === 'about') {
      title = "About Us | Siri Tax Consultancy Vizag & Srikakulam";
      description = "Learn more about Siri Tax Consultancy, our history starting in 2019, our values, and our mission to simplify taxation.";
    } else if (currentPage === 'services-list') {
      title = "Our Services | Siri Tax Consultancy Vizag & Srikakulam";
      description = "Explore our wide range of tax and accounting services including GST registration, ITR filing, and MSME registration across multiple locations.";
    } else if (currentPage === 'service-detail' && selectedService) {
      title = `${selectedService.title} | Siri Tax Consultancy`;
      description = selectedService.metaDescription;
    } else if (currentPage === 'gst-calculator') {
      title = "GST Calculator India | Exclusive & Inclusive GST Tool";
      description = "Easy to use GST calculator for Indian tax slabs (5%, 12%, 18%, 28%). Calculate GST inclusive and exclusive amounts.";
    } else if (currentPage === 'rules') {
      title = "Tax Rules 2024-25 | Income Tax Slabs & GST Guide";
      description = "Latest guide to Indian Income Tax slabs for AY 2025-26 and current GST rates. Stay compliant with recent regulations.";
    }

    document.title = title;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', description);

    // Update JSON-LD
    const updateJsonLd = () => {
      const existingScript = document.getElementById('json-ld');
      if (existingScript) existingScript.remove();

      const jsonLd = {
        "@context": "https://schema.org",
        "@type": "TaxConsultancy",
        "name": "Siri Tax Consultancy",
        "image": "https://images.unsplash.com/photo-1554224155-6726b3ff858f",
        "@id": "https://siritax.com",
        "url": "https://siritax.com",
        "telephone": "+91 89777 56671",
        "address": [
          {
            "@type": "PostalAddress",
            "streetAddress": "Visakhapatnam Main Center",
            "addressLocality": "Visakhapatnam",
            "postalCode": "530001",
            "addressCountry": "IN"
          },
          {
            "@type": "PostalAddress",
            "streetAddress": "Srikakulam Town",
            "addressLocality": "Srikakulam",
            "postalCode": "532001",
            "addressCountry": "IN"
          }
        ],
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": 17.6868,
          "longitude": 83.2185
        },
        "openingHoursSpecification": {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          "opens": "09:00",
          "closes": "18:00"
        },
        "sameAs": [
          "https://facebook.com/siritax",
          "https://twitter.com/siritax"
        ]
      };

      const script = document.createElement('script');
      script.id = 'json-ld';
      script.type = 'application/ld+json';
      script.text = JSON.stringify(jsonLd);
      document.head.appendChild(script);
    };

    updateJsonLd();
  }, [currentPage, selectedService]);

  return null; // Side-effect only component
};

export default SEOManager;
