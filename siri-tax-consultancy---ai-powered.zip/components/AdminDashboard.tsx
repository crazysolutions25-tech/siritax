
import React, { useState, useEffect } from 'react';
import { MockAPI } from '../services/api';

const AdminDashboard: React.FC = () => {
  const [leads, setLeads] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  const fetchLeads = async () => {
    setLoading(true);
    const res = await MockAPI.leads.getAll();
    if (res.success) setLeads(res.data || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  const handleStatusChange = async (id: number, newStatus: string) => {
    await MockAPI.leads.updateStatus(id, newStatus);
    fetchLeads();
  };

  const filteredLeads = leads.filter(l => filter === 'All' || l.status === filter);

  const stats = {
    total: leads.length,
    pending: leads.filter(l => l.status === 'Pending').length,
    resolved: leads.filter(l => l.status === 'Resolved').length
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-24 sm:pt-32 pb-20 px-4 sm:px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-10 gap-6">
          <div>
            <h1 className="text-3xl sm:text-4xl font-serif text-slate-900 mb-2">Backend Management</h1>
            <p className="text-slate-500 text-sm">Monitor inquiries and lead status.</p>
          </div>
          <button 
            onClick={fetchLeads}
            className="w-full lg:w-auto px-6 py-3.5 bg-white border border-slate-200 rounded-xl text-slate-700 font-bold hover:bg-slate-50 transition-all flex items-center justify-center space-x-2 shadow-sm"
          >
            <svg className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
            <span>Refresh Database</span>
          </button>
        </div>

        {/* Analytics Mini-Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-10">
          {[
            { label: 'Total Inquiries', val: stats.total, color: 'indigo' },
            { label: 'Pending Action', val: stats.pending, color: 'amber' },
            { label: 'Resolved Success', val: stats.resolved, color: 'emerald' }
          ].map(stat => (
            <div key={stat.label} className="bg-white p-6 sm:p-8 rounded-[1.5rem] sm:rounded-[2rem] border border-slate-100 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{stat.label}</span>
              <div className={`text-3xl sm:text-4xl font-serif text-${stat.color}-600 mt-2`}>{stat.val}</div>
            </div>
          ))}
        </div>

        {/* Leads Management Table */}
        <div className="bg-white rounded-[1.5rem] sm:rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden">
          <div className="p-6 sm:p-8 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h3 className="font-bold text-lg sm:text-xl text-slate-900">Recent Inquiries</h3>
            <div className="flex flex-wrap gap-2">
              {['All', 'Pending', 'Contacted', 'Resolved'].map(f => (
                <button 
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 rounded-full text-[10px] font-bold transition-all ${filter === f ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <div className="overflow-x-auto">
              <table className="w-full text-left min-w-[800px]">
                <thead>
                  <tr className="bg-slate-50 text-slate-400 text-[10px] uppercase font-bold tracking-widest">
                    <th className="px-8 py-4">Client</th>
                    <th className="px-8 py-4">Requested Service</th>
                    <th className="px-8 py-4">Submitted Date</th>
                    <th className="px-8 py-4">Status</th>
                    <th className="px-8 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-slate-50">
                  {loading ? (
                    <tr><td colSpan={5} className="text-center py-20 text-slate-400 italic">Syncing with Backend...</td></tr>
                  ) : filteredLeads.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-20 text-slate-400">No leads match your criteria.</td></tr>
                  ) : filteredLeads.map(lead => (
                    <tr key={lead.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-8 py-6">
                        <div className="font-bold text-slate-900">{lead.name}</div>
                        <div className="text-xs text-slate-400">{lead.email}</div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-[10px] font-bold uppercase">{lead.service}</span>
                      </td>
                      <td className="px-8 py-6 text-slate-500">
                        {new Date(lead.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-8 py-6">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                          lead.status === 'Resolved' ? 'bg-emerald-50 text-emerald-600' : 
                          lead.status === 'Contacted' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'
                        }`}>
                          {lead.status}
                        </span>
                      </td>
                      <td className="px-8 py-6">
                        <select 
                          value={lead.status}
                          onChange={(e) => handleStatusChange(lead.id, e.target.value)}
                          className="bg-slate-50 border border-slate-100 text-indigo-600 font-bold text-[10px] outline-none cursor-pointer hover:bg-indigo-50 px-2 py-1 rounded"
                        >
                          <option value="Pending">Set Pending</option>
                          <option value="Contacted">Set Contacted</option>
                          <option value="Resolved">Set Resolved</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Mobile Swipe Hint */}
            <div className="md:hidden flex justify-center py-3 bg-slate-50/80 text-[9px] uppercase tracking-widest font-bold text-slate-400">
              <svg className="w-3 h-3 mr-2 animate-bounce-x" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
              Swipe left/right to view all columns
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
